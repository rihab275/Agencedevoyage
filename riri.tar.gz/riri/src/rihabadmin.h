#include <gtk/gtk.h>

int verifier (char login[],char passwordentry[]);

/*-------------------structure_reservation hotel---------------------*/

typedef struct
{

char id[10];
char n_hotel[20];
char adulte[3];
char enfant[3];
char bebe[3];
char de_jour[3];
char de_mois[3];
char de_an[5];
char a_jour[3];
char a_mois[3];
char a_an[5];
char prix[10];


}reservation;

void ajouter_reservation(reservation r);

void afficher_reservation(GtkWidget *liste);

void supprimer_reservation(char *idd);

void modifier_reservation(reservation r);

int exist_reservation(char *id);

/*-------------------structure_reservation vol---------------------*/

typedef struct
{

char id[10];
char depart[20];
char arrive[20];
char nb_pass[3];
char de_jour[3];
char de_mois[3];
char de_an[5];
char a_jour[3];
char a_mois[3];
char a_an[5];
char prix[10];


}reservationvol;

void ajouter_reservationvol(reservationvol rv);

void afficher_reservationvol(GtkWidget *liste);

void supprimer_reservationvol(char idd[20]);

void modifier_reservationvol(reservationvol rv);

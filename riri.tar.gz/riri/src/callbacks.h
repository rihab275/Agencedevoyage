#include <gtk/gtk.h>
#include <gtk/gtk.h>
typedef struct vol vol;
struct vol{
char id[30];
char depart[30];
char destination[30];
char companie[30];
char date_depart[30];
char date_retour[30];
int nbVols;
int prix;
};

typedef struct hotel hotel;
struct hotel{
char nom[30];
char typeChambre[30];
char dateAdmission[30];
char dateSortie[30];
int nbChambre;
int prix;
};
int i,j;

GtkWidget *acceuil;
  GtkWidget *gestion_Hotel;
  GtkWidget *gestio_Vol;
  GtkWidget *catalogue;




void
on_Rbutton_cnx_clicked                 (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_Gres_Eadmin_clicked         (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttondecnx_gres_Eagent_clicked    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_resH_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_resV_clicked                (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttondecnx_gres_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_reshotel_clicked      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonAjout_resH_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonaff_resH_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonModif_resH_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonSupp_resH_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_resH_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonconf_resH_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_chehotel_clicked      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonconf_chehotel_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonval_modres_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_modres_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_resvol_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonAff_resV_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_Ajouter_resV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_Modif_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonsupp_listeV_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonconf_Supp_resV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_confsuppresV_clicked  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonval_Modif_resH_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_ModifresH_clicked     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonconf_cherV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_cherresV_clicked      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonval_modif_resV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_modifresV_clicked     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_ajV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonval_ajoutV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonVol_Eclient_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_decnx_Eclient_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonmesres_Eclient_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_RbuttonH_Eclient_clicked            (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonres_Eclient_clicked          (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_resh_Eclient_clicked  (GtkWidget       *obj,
                                        gpointer         user_data);
/*************************************************************************************************************************************/
void
on_AcceuilgestionHotel_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_AcceuilgestionV_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AcceuiCatalogue_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterHotel_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_SupprimerHotel_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierHotel_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherHotel_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionHotel_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_gtk_main_quit_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterVol_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_SupprimerVol_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierVol_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionVol_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_catalogue_Acceuil_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_bouttonrechdhia_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Rbutton5_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rsbutton25_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbuttonretour_ajout_Eclient_clicked (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rssbutton_res_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rssbuttonretour_listeV_clicked      (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rssbuttonretour_listV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_Rbutton_valresV_clicked             (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_YbuttonaffresVoit_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_YbuttonajoutresVoit_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ybuttonmodif_resVoit_clicked        (GtkButton       *button,
                                        gpointer         user_data);

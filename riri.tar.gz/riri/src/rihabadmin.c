#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rihabadmin.h"
#include <gtk/gtk.h>

/*-----------------authentification-(vérifier)----------------------*/

int verifier (char login[],char passwordentry[])
{
FILE *f;
char username[20];
char password[20];
int role;
f=fopen("/home/rihab/riri/src/users.txt","r");
if(f!=NULL)
{ 
while (fscanf(f,"%s %s %d",username,password,&role)!=EOF)
  { 
if ((strcmp(login,username)==0) && strcmp(passwordentry,password)==0)
{
	return(role);
}
}
return 0;
}
fclose(f);
}

///////////////////reservation hotel//////////////////////

/*------------------------ajouter_reservation--------------------------*/

void ajouter_reservation(reservation r)
{
 
 FILE *f;
  f=fopen("/home/rihab/riri/src/reservation.txt","a+");
  if(f!=NULL)  
  {fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",r.id,r.n_hotel,r.adulte,r.enfant,r.bebe,r.de_jour,r.de_mois,r.de_an,r.a_jour,r.a_mois,r.a_an,r.prix);
  fclose(f);
      

   
  }

}

/*---------------------afficher_reservation----------------------------*/

enum
{
	ID,
	N_HOTEL,
        DATE_A,
        DATE_R,
        PRIX,
	COLUMNS
};

void afficher_reservation(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char id[10];
        char n_hotel[20];
        char adulte[3];
        char enfant[3];
        char bebe[3];
        char de_jour[3];
        char de_mois[3];
        char de_an[5];
        char a_jour[3];
        char a_mois[3];
        char a_an[5];
        char prix[10];
        char dateretour[20];
        char datealler[20];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Identifiant", renderer, "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Nom hotel", renderer, "text",N_HOTEL, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Date aller", renderer, "text",DATE_A, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Date retour", renderer, "text",DATE_R, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Prix", renderer, "text",PRIX, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("/home/rihab/riri/src/reservation.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("/home/rihab/riri/src/reservation.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",id,n_hotel,adulte,enfant,bebe,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix)!=EOF)
		{
                   if(id[0]!='-')
			{
			 strcpy(datealler,de_jour);strcat(datealler,"/");
			 strcat(datealler,de_mois);strcat(datealler,"/");
			 strcat(datealler,de_an);
                         strcpy(dateretour,a_jour);strcat(dateretour,"/");
			 strcat(dateretour,a_mois);strcat(dateretour,"/");
			 strcat(dateretour,a_an);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, ID, id, N_HOTEL, n_hotel, DATE_A,datealler,DATE_R,dateretour ,PRIX, prix, -1); 
			}
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}

}
/*-----------------------supprimer_reservation----------------------------*/

void supprimer_reservation(char *idd)
{
	char id[10];
        char n_hotel[20];
        char adulte[3];
        char enfant[3];
        char bebe[3];
        char de_jour[3];
        char de_mois[3];
        char de_an[5];
        char a_jour[3];
        char a_mois[3];
        char a_an[5];
        char prix[10];

	FILE *l;
	FILE *t;
	l=fopen("/home/rihab/riri/src/reservation.txt","r");
	t=fopen("/home/rihab/riri/src/reservation.tmp","a+");
	while (fscanf(l,"%s %s %s %s %s %s %s %s %s %s %s %s  \n",id,n_hotel,adulte,enfant,bebe,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix)!=EOF)
	{
		if (strcmp(idd,id)!=0)
		{
			fprintf(t,"%s %s %s %s %s %s %s %s %s %s %s %s \n",id,n_hotel,adulte,enfant,bebe,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix);
		}
	}
	fclose(l);
	fclose(t);
	remove("/home/rihab/riri/src/reservation.txt");
	rename("/home/rihab/riri/src/reservation.tmp","reservation.txt");
}

/*-----------------------modifier_reservation----------------------------*/

void modifier_reservation(reservation r)
{
reservation ra;
FILE *f;
FILE *f1;


f=fopen("/home/rihab/riri/src/reservation.txt","r");
f1=fopen("/home/rihab/riri/src/reservation.tmp","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s ",ra.id,ra.n_hotel,ra.adulte,ra.enfant,ra.bebe,ra.de_jour,ra.de_mois,ra.de_an,ra.a_jour,ra.a_mois,ra.a_an,ra.prix)!=EOF)
{
	if (strcmp(r.id,ra.id)!=0)
	{
		fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s  \n",ra.id,ra.n_hotel,ra.adulte,ra.enfant,ra.bebe,ra.de_jour,ra.de_mois,ra.de_an,ra.a_jour,ra.a_mois,ra.a_an,ra.prix);}
	else {
		fprintf(f1,"%s %s %s %s %s %s %s %s  %s %s %s %s \n",r.id,r.n_hotel,r.adulte,r.enfant,r.bebe,r.de_jour,r.de_mois,r.de_an,r.a_jour,r.a_mois,r.a_an,r.prix);  } 
}
fclose(f);
fclose(f1);

remove("/home/rihab/riri/src/reservation.txt") ;
rename("/home/rihab/riri/src/reservation.tmp" , "/home/rihab/riri/src/reservation.txt");
}


/*************************************verifier existance *******************************************************************************/

int exist_reservation(char *id)
{
FILE*f=NULL;
reservation rh;
f=fopen("/home/rihab/riri/src/reservation.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",rh.id,rh.n_hotel,rh.adulte,rh.enfant,rh.bebe,rh.de_jour,rh.de_mois,rh.de_an,rh.a_jour,rh.a_mois,rh.a_an,rh.prix)!=EOF){
if(strcmp(rh.id,id)==0)return 1;
}
fclose(f);
return 0;
}
///////////////////reservation vol//////////////////////

void ajouter_reservationvol(reservationvol rv)
{

 FILE *f;
  f=fopen("/home/rihab/riri/src/reservationvol.txt","a+");
  if(f!=NULL)
  {
  fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",rv.id,rv.depart,rv.arrive,rv.nb_pass,rv.de_jour,rv.de_mois,rv.de_an,rv.a_jour,rv.a_mois,rv.a_an,rv.prix);
  fclose(f);

  }

}

/*---------------------afficher_reservation vol----------------------------*/

enum
{
	IDV,
	DEPARTV,
        ARRIVEV,
        NB_PASSV,
        DATE_AV,
        DATE_RV,
        PRIXV,
	COLUMNSV
};

void afficher_reservationvol(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char id[10];
        char depart[20];
        char arrive[20];
        char nb_pass[3];
        char de_jour[3];
        char de_mois[3];
        char de_an[5];
        char a_jour[3];
        char a_mois[3];
        char a_an[5];
        char prix[10];
        char dateretour[20];
        char datealler[20];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Identifiant", renderer, "text",IDV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Départ", renderer, "text",DEPARTV, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Arrivé", renderer, "text",ARRIVEV, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Nombre passagers", renderer, "text",NB_PASSV, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Date aller", renderer, "text",DATE_AV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Date retour", renderer, "text",DATE_RV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Prix", renderer, "text",PRIXV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	}

	
	store=gtk_list_store_new (COLUMNSV, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("/home/rihab/riri/src/reservationvol.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("/home/rihab/riri/src/reservationvol.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",id,depart,arrive,nb_pass,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix)!=EOF)
		{
                   if(id[0]!='-')
			{
			 strcpy(datealler,de_jour);strcat(datealler,"/");
			 strcat(datealler,de_mois);strcat(datealler,"/");
			 strcat(datealler,de_an);
                         strcpy(dateretour,a_jour);strcat(dateretour,"/");
			 strcat(dateretour,a_mois);strcat(dateretour,"/");
			 strcat(dateretour,a_an);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, IDV, id, DEPARTV, depart, ARRIVEV, arrive, NB_PASSV, nb_pass, DATE_AV,datealler,DATE_RV,dateretour ,PRIXV, prix, -1); 
			}
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}

}


/*-----------------------supprimer reservation vol----------------------------*/

void supprimer_reservationvol(char idd[20])
{
	char id[10];
        char depart[20];
        char arrive[20];
        char nb_pass[3];
        char de_jour[3];
        char de_mois[3];
        char de_an[5];
        char a_jour[3];
        char a_mois[3];
        char a_an[5];
        char prix[10];

	FILE *l;
	FILE *t;
	l=fopen("/home/rihab/riri/src/reservationvol.txt","r");
	t=fopen("/home/rihab/riri/src/reservationvol.tmp","a+");
	while (fscanf(l,"%s %s %s %s %s %s %s %s %s %s %s  \n",id,depart,arrive,nb_pass,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix)!=EOF)
	{
		if (strcmp(idd,id)!=0)
		{
			fprintf(t,"%s %s %s %s %s %s %s %s %s %s %s \n",id,depart,arrive,nb_pass,de_jour,de_mois,de_an,a_jour,a_mois,a_an,prix);
		}
	}
	fclose(l);
	fclose(t);
	remove("/home/rihab/riri/src/reservationvol.txt");
	rename("/home/rihab/riri/src/reservationvol.tmp","reservationvol.txt");
}



/*-----------------------modifier reservation vol----------------------------*/

void modifier_reservationvol(reservationvol rv)
{
reservationvol rva;
FILE *fv;
FILE *fv1;


fv=fopen("/home/rihab/riri/src/reservationvol.txt","r");
fv1=fopen("/home/rihab/riri/src/reservationvol.tmp","a+");
while (fscanf(fv,"%s %s %s %s %s %s %s %s %s %s %s ",rva.id,rva.depart,rva.arrive,rva.nb_pass,rva.de_jour,rva.de_mois,rva.de_an,rva.a_jour,rva.a_mois,rva.a_an,rva.prix)!=EOF)
{
	if (strcmp(rv.id,rva.id)!=0)
	{
		fprintf(fv1,"%s %s %s %s %s %s %s %s %s %s %s  \n",rva.id,rva.depart,rva.arrive,rva.nb_pass,rva.de_jour,rva.de_mois,rva.de_an,rva.a_jour,rva.a_mois,rva.a_an,rva.prix);}
	else {
		fprintf(fv1,"%s %s %s %s %s %s %s %s  %s %s %s \n",rv.id,rv.depart,rv.arrive,rv.nb_pass,rv.de_jour,rv.de_mois,rv.de_an,rv.a_jour,rv.a_mois,rv.a_an,rv.prix);  } 
}
fclose(fv);
fclose(fv1);

remove("/home/rihab/riri/src/reservationvol.txt") ;
rename("/home/rihab/riri/src/reservationvol.tmp" , "reservationvol.txt");
}

///////////////////reservation hotel pour agent//////////////////////










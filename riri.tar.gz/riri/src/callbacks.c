#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "rihabadmin.h"
#include"tree.h"
#include"crud.h"

//connexion
void
on_Rbutton_cnx_clicked                 (GtkWidget       *widget,
                                        gpointer         user_data)
{
int V ;
GtkWidget *login ;
GtkWidget *password1 ;
GtkWidget *role1 ;
GtkWidget *espaceadmin ;
GtkWidget *authentification;
GtkWidget *espaceagent;
GtkWidget *espaceclient;


espaceadmin=create_espaceadmin();
espaceagent=create_espaceagent();
espaceclient=create_espaceclient();
char username[20];
char password[20];
int role ;
login=lookup_widget(widget ,"Rentry1");
password1=lookup_widget(widget ,"Rentry2");
//role=lookup_widget(widget,"role")

strcpy(username,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(password1)));
V = verifier (username , password );
if (V==1){
gtk_widget_show(espaceadmin);
gtk_widget_hide(GTK_WIDGET(lookup_widget(widget,"authentification")));}
if (V==2){
gtk_widget_show(espaceagent);
gtk_widget_hide(GTK_WIDGET(lookup_widget(widget,"authentification")));
} 
if (V==3){
gtk_widget_show(espaceclient);
gtk_widget_hide(GTK_WIDGET(lookup_widget(widget,"authentification")));
} 
}

/**********************************************espace admin*******************************************************************************/
void
on_Rbutton_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data)
{

}


void
on_Rbutton_Gres_Eadmin_clicked         (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *espaceadmin, *gestionres;

espaceadmin=lookup_widget(obj,"espaceadmin");

gtk_widget_destroy(espaceadmin);
gestionres=create_gestionres();
gtk_widget_show(gestionres);
}

//deconnexion
void
on_Rbuttondecnx_gres_Eagent_clicked    (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *espaceadmin, *authentification;

espaceadmin=lookup_widget(obj,"espaceadmin");

gtk_widget_destroy(espaceadmin);
authentification=create_authentification();
gtk_widget_show(authentification);
}

/****************************************************gestion reservation*********************************************************************/
void
on_Rbutton_resH_clicked                (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rhotels, *gestionres;

gestionres=lookup_widget(obj,"gestionres");

gtk_widget_destroy(gestionres);
Rhotels=create_Rhotels();
gtk_widget_show(Rhotels);
}


void
on_Rbutton_resV_clicked                (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rvol, *gestionres;

gestionres=lookup_widget(obj,"gestionres");

gtk_widget_destroy(gestionres);
Rvol=create_Rvol();
gtk_widget_show(Rvol);
}

//deconnexion
void
on_Rbuttondecnx_gres_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *gestionres, *authentification;

gestionres=lookup_widget(obj,"gestionres");

gtk_widget_destroy(gestionres);
authentification=create_authentification();
gtk_widget_show(authentification);
}

//retour
void
on_Rbuttonretour_reshotel_clicked      (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rhotels, *gestionres;

Rhotels=lookup_widget(obj,"Rhotels");

gtk_widget_destroy(Rhotels);
gestionres=create_gestionres();
gtk_widget_show(gestionres);
}

/***************************************************afficher espace reservation hotel**********************************************/

void
on_RbuttonAjout_resH_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rhotels, *RajouterH;

Rhotels=lookup_widget(obj,"Rhotels");

gtk_widget_destroy(Rhotels);
RajouterH=create_RajouterH();
gtk_widget_show(RajouterH);
}


void
on_Rbuttonaff_resH_clicked             (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"Rhotels");
 new=create_RafficherH();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rtreeview1");
 afficher_reservation(treeview);
 gtk_widget_destroy(old);
}

/*******************************************affichage reservation hotel******************************************************************/
void
on_RbuttonModif_resH_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RafficherH, *RcherH;

RafficherH=lookup_widget(obj,"RafficherH");

gtk_widget_destroy(RafficherH);
RcherH=create_RcherH();
gtk_widget_show(RcherH);
}


void
on_RbuttonSupp_resH_clicked            (GtkWidget       *obj,
                                        gpointer         user_data)
{
        GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* Rtreeview1;
        GtkWidget *RafficherH;
        gchar* id;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*

        RafficherH=lookup_widget(obj,"RafficherH");
        Rtreeview1=lookup_widget(RafficherH,"Rtreeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(Rtreeview1));

        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_reservation(id);// supprimer la ligne du fichier

         }
}

void
on_Rbuttonretour_resH_clicked          (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rhotels, *RafficherH;

RafficherH=lookup_widget(obj,"RafficherH");

gtk_widget_destroy(RafficherH);
Rhotels=create_Rhotels();
gtk_widget_show(Rhotels);
}

/****************************************confirmer supp reservation********************************************************************/
void
on_Rbuttonconf_resH_clicked            (GtkWidget       *obj,
                                        gpointer         user_data)
{
}


void
on_Rbuttonretour_chehotel_clicked      (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"RcherH");
 new=create_RafficherH();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rtreeview1");
 afficher_reservation(treeview);
 gtk_widget_destroy(old);

}

/************************************************confirmer recherche res*********************************************************************/
void
on_Rbuttonconf_chehotel_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RmodifH, *RcherH;
GtkWidget *output1 , *output2 , *output3,*output4,*output5,*output6, *output7, *output8,*output9,*output10, *output11, *output12;
GtkWidget *input1;
reservation r;
char idd[30];
FILE *f;

	input1=lookup_widget(obj,"Rentry4");

	strcpy (idd,gtk_entry_get_text(GTK_ENTRY(input1)));

  f=fopen("/home/rihab/riri/src/reservation.txt","r"); 
   if (f!=NULL)
   {
    while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",r.id,r.n_hotel,r.adulte,r.enfant,r.bebe,r.de_jour,r.de_mois,r.de_an,r.a_jour,r.a_mois,r.a_an,r.prix)!=EOF)
	{
   if ((strcmp(r.id,idd)==0))
		{  	
	RcherH=lookup_widget(obj,"RcherH");
	gtk_widget_destroy(RcherH);
	RmodifH=create_RmodifH();
	gtk_widget_show(RmodifH);

	output1=lookup_widget(RmodifH,"Rentry5");
	output2=lookup_widget(RmodifH,"Rentry6");
	output3=lookup_widget(RmodifH,"Rspinbutton7");
	output4=lookup_widget(RmodifH,"Rspinbutton8");
	output5=lookup_widget(RmodifH,"Rspinbutton9");
	output6=lookup_widget(RmodifH,"Rspinbutton3");
	output7=lookup_widget(RmodifH,"Rspinbutton2");
	output8=lookup_widget(RmodifH,"Rspinbutton1");
	output9=lookup_widget(RmodifH,"Rspinbutton4");
	output10=lookup_widget(RmodifH,"Rspinbutton5");
	output11=lookup_widget(RmodifH,"Rspinbutton6");
	output12=lookup_widget(RmodifH,"Rentry7");

	gtk_entry_set_text(GTK_ENTRY(output1),r.id);
	gtk_entry_set_text(GTK_ENTRY(output2),r.n_hotel);
	gtk_entry_set_text(GTK_ENTRY(output3),r.adulte);
	gtk_entry_set_text(GTK_ENTRY(output4),r.enfant);
	gtk_entry_set_text(GTK_ENTRY(output5),r.bebe);
	gtk_entry_set_text(GTK_ENTRY(output6),r.de_jour);
	gtk_entry_set_text(GTK_ENTRY(output7),r.de_mois);
	gtk_entry_set_text(GTK_ENTRY(output8),r.de_an);
	gtk_entry_set_text(GTK_ENTRY(output9),r.a_jour);
	gtk_entry_set_text(GTK_ENTRY(output10),r.a_mois);
	gtk_entry_set_text(GTK_ENTRY(output11),r.a_an);
	gtk_entry_set_text(GTK_ENTRY(output12),r.prix);
		}
	}	
   }
    fclose(f);
}


void
on_Rbuttonval_modres_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
reservation r;

GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
GtkWidget *RmodifH, *Rhotels;
RmodifH=lookup_widget(obj,"RmodifH");

input1=lookup_widget(obj,"Rentry5");
input2=lookup_widget(obj,"Rentry6");
input3=lookup_widget(obj,"Rspinbutton7");
input4=lookup_widget(obj,"Rspinbutton8");
input5=lookup_widget(obj,"Rspinbutton9");
input6=lookup_widget(obj,"Rspinbutton3");
input7=lookup_widget(obj,"Rspinbutton2");
input8=lookup_widget(obj,"Rspinbutton1");
input9=lookup_widget(obj,"Rspinbutton4");
input10=lookup_widget(obj,"Rspinbutton5");
input11=lookup_widget(obj,"Rspinbutton6");
input12=lookup_widget(obj,"Rentry7");

strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.n_hotel,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.adulte,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.enfant,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.bebe,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.de_jour,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(r.de_mois,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(r.de_an,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(r.a_jour,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(r.a_mois,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(r.a_an,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(r.prix,gtk_entry_get_text(GTK_ENTRY(input12)));

modifier_reservation(r);


RmodifH=lookup_widget(obj,"RmodifH");

gtk_widget_destroy(RmodifH);
Rhotels=create_Rhotels();
gtk_widget_show(Rhotels);
}


void
on_Rbuttonretour_modres_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rhotels, *RmodifH;

RmodifH=lookup_widget(obj,"RmodifH");

gtk_widget_destroy(RmodifH);
Rhotels=create_Rhotels();
gtk_widget_show(Rhotels);
}

/******************************************reservation vol*************************************************************************/
void
on_Rbuttonretour_resvol_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *gestionres, *Rvol;

Rvol=lookup_widget(obj,"Rvol");

gtk_widget_destroy(Rvol);
gestionres=create_gestionres();
gtk_widget_show(gestionres);
}


void
on_RbuttonAff_resV_clicked             (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"Rvol");
 new=create_RafficherV();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rtreeview2");
 afficher_reservationvol(treeview);
 gtk_widget_destroy(old);
}


void
on_Rbutton_Ajouter_resV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *Rvol, *RajouterV;

Rvol=lookup_widget(obj,"Rvol");

gtk_widget_destroy(Rvol);
RajouterV=create_RajouterV();
gtk_widget_show(RajouterV);
}


void
on_Rbutton_Modif_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RafficherV, *RcherV;

RafficherV=lookup_widget(obj,"RafficherV");

gtk_widget_destroy(RafficherV);
RcherV=create_RcherV();
gtk_widget_show(RcherV);
}


void
on_Rbuttonsupp_listeV_clicked          (GtkWidget       *obj,
                                        gpointer         user_data)
{

        GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* Rtreeview2;
        GtkWidget *RafficherV;
        gchar* id;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*

        RafficherV=lookup_widget(obj,"RafficherV");
        Rtreeview2=lookup_widget(RafficherV,"Rtreeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(Rtreeview2));

        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_reservationvol(id);// supprimer la ligne du fichier

         }
}


void
on_Rbuttonretour_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RafficherV, *Rvol;

RafficherV=lookup_widget(obj,"RafficherV");

gtk_widget_destroy(RafficherV);
Rvol=create_Rvol();
gtk_widget_show(Rvol);
}

//
void
on_Rbuttonconf_Supp_resV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{

}


void
on_Rbuttonretour_confsuppresV_clicked  (GtkWidget       *obj,
                                        gpointer         user_data)
{

}

/*******************************************ajouter res hotel**************************************************************************/
void
on_Rbuttonval_Modif_resH_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{
reservation r;

GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
GtkWidget *RajouterH;

RajouterH=lookup_widget(obj,"RajouterH");

input1=lookup_widget(obj,"Rentry9");
input2=lookup_widget(obj,"Rentry10");
input3=lookup_widget(obj,"Rspinbutton16");
input4=lookup_widget(obj,"Rspinbutton17");
input5=lookup_widget(obj,"Rspinbutton18");
input6=lookup_widget(obj,"Rspinbutton12");
input7=lookup_widget(obj,"Rspinbutton11");
input8=lookup_widget(obj,"Rspinbutton10");
input9=lookup_widget(obj,"Rspinbutton13");
input10=lookup_widget(obj,"Rspinbutton14");
input11=lookup_widget(obj,"Rspinbutton15");
input12=lookup_widget(obj,"Rentry11");

strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.n_hotel,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.adulte,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.enfant,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.bebe,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.de_jour,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(r.de_mois,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(r.de_an,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(r.a_jour,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(r.a_mois,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(r.a_an,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(r.prix,gtk_entry_get_text(GTK_ENTRY(input12)));

//ajouter_reservation(r);

GtkWidget *Rhotels;
GtkWidget *labelid;
GtkWidget *labelnom;

labelid=lookup_widget(RajouterH,"labelerr1");
labelnom=lookup_widget(RajouterH,"labelerr2");



int b=1;
// controle saisie
if(strcmp(r.id,"")==0){
		  gtk_widget_show (labelid);
b=0;
}
else {
		  gtk_widget_hide(labelid);
}

if(strcmp(r.n_hotel,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}



if(b==1){

						  
                ajouter_reservation(r);
		gtk_widget_destroy(RajouterH);
                Rhotels=create_Rhotels();
                gtk_widget_show(Rhotels);

					
        }

}


void
on_Rbuttonretour_ModifresH_clicked     (GtkWidget       *obj,
                                        gpointer         user_data)
{

}
/*********************************************************************************************************************************************/

void
on_Rbuttonconf_cherV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RmodifV, *RcherV;
GtkWidget *output1 , *output2 , *output3,*output4,*output5,*output6, *output7, *output8,*output9,*output10, *output11;
GtkWidget *input1;
reservationvol rv;
char idd[30];
FILE *f;

	input1=lookup_widget(obj,"Rentry12");

	strcpy (idd,gtk_entry_get_text(GTK_ENTRY(input1)));

  f=fopen("/home/rihab/riri/src/reservationvol.txt","r"); 
   if (f!=NULL)
   {
    while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",rv.id,rv.depart,rv.arrive,rv.nb_pass,rv.de_jour,rv.de_mois,rv.de_an,rv.a_jour,rv.a_mois,rv.a_an,rv.prix)!=EOF)
	{
   if ((strcmp(rv.id,idd)==0))
		{  	
	RcherV=lookup_widget(obj,"RcherV");
	gtk_widget_destroy(RcherV);
	RmodifV=create_RmodifV();
	gtk_widget_show(RmodifV);

	output1=lookup_widget(RmodifV,"Rentry13");
	output2=lookup_widget(RmodifV,"Rentry14");
	output3=lookup_widget(RmodifV,"Rentry16");
	output4=lookup_widget(RmodifV,"Rspinbutton25");
	output5=lookup_widget(RmodifV,"Rspinbutton21");
	output6=lookup_widget(RmodifV,"Rspinbutton20");
	output7=lookup_widget(RmodifV,"Rspinbutton19");
	output8=lookup_widget(RmodifV,"Rspinbutton22");
	output9=lookup_widget(RmodifV,"Rspinbutton23");
	output10=lookup_widget(RmodifV,"Rspinbutton24");
	output11=lookup_widget(RmodifV,"Rentry15");

	gtk_entry_set_text(GTK_ENTRY(output1),rv.id);
	gtk_entry_set_text(GTK_ENTRY(output2),rv.depart);
	gtk_entry_set_text(GTK_ENTRY(output3),rv.arrive);
	gtk_entry_set_text(GTK_ENTRY(output4),rv.nb_pass);
	gtk_entry_set_text(GTK_ENTRY(output5),rv.de_jour);
	gtk_entry_set_text(GTK_ENTRY(output6),rv.de_mois);
	gtk_entry_set_text(GTK_ENTRY(output7),rv.de_an);
	gtk_entry_set_text(GTK_ENTRY(output8),rv.a_jour);
	gtk_entry_set_text(GTK_ENTRY(output9),rv.a_mois);
	gtk_entry_set_text(GTK_ENTRY(output10),rv.a_an);
	gtk_entry_set_text(GTK_ENTRY(output11),rv.prix);
		}
	}	
   }
    fclose(f);
}


void
on_Rbuttonretour_cherresV_clicked      (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"RcherV");
 new=create_RafficherV();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rtreeview2");
 afficher_reservationvol(treeview);
 gtk_widget_destroy(old);
}


void
on_Rbuttonval_modif_resV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{
reservationvol rv;

GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
GtkWidget *RmodifV, *Rvol;

RmodifV=lookup_widget(obj,"RmodifV");

input1=lookup_widget(obj,"Rentry13");
input2=lookup_widget(obj,"Rentry14");
input3=lookup_widget(obj,"Rentry16");
input4=lookup_widget(obj,"Rspinbutton25");
input5=lookup_widget(obj,"Rspinbutton21");
input6=lookup_widget(obj,"Rspinbutton20");
input7=lookup_widget(obj,"Rspinbutton19");
input8=lookup_widget(obj,"Rspinbutton22");
input9=lookup_widget(obj,"Rspinbutton23");
input10=lookup_widget(obj,"Rspinbutton24");
input11=lookup_widget(obj,"Rentry15");

strcpy(rv.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(rv.depart,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(rv.arrive,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rv.nb_pass,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(rv.de_jour,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(rv.de_mois,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(rv.de_an,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(rv.a_jour,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(rv.a_mois,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(rv.a_an,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(rv.prix,gtk_entry_get_text(GTK_ENTRY(input11)));

modifier_reservationvol(rv);


RmodifV=lookup_widget(obj,"RmodifV");

gtk_widget_destroy(RmodifV);
Rvol=create_Rvol();
gtk_widget_show(Rvol);
}


void
on_Rbuttonretour_modifresV_clicked     (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RajouterV, *Rvol;

RajouterV=lookup_widget(obj,"RajouterV");

gtk_widget_destroy(RajouterV);
Rvol=create_Rvol();
gtk_widget_show(Rvol);
}
/*************************************************valider ajout reservation vol***********************************************************/

void
on_Rbuttonretour_ajV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"RmodifV");
 new=create_RafficherV();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rtreeview2");
 afficher_reservationvol(treeview);
 gtk_widget_destroy(old);
}


void
on_Rbuttonval_ajoutV_clicked           (GtkWidget       *obj,
                                        gpointer         user_data)
{
reservationvol rv;

GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11;
GtkWidget *RajouterV;
GtkWidget *Rvol;
GtkWidget *Rlabelerreur_resvol;
RajouterV=lookup_widget(obj,"RajouterV");

input1=lookup_widget(obj,"RSentry1");
input2=lookup_widget(obj,"RSentry2");
input3=lookup_widget(obj,"RSentry4");
input4=lookup_widget(obj,"RSspinbutton7");
input5=lookup_widget(obj,"RSspinbutton3");
input6=lookup_widget(obj,"RSspinbutton2");
input7=lookup_widget(obj,"RSspinbutton1");
input8=lookup_widget(obj,"RSspinbutton4");
input9=lookup_widget(obj,"RSspinbutton5");
input10=lookup_widget(obj,"RSspinbutton6");
input11=lookup_widget(obj,"RSentry3");

strcpy(rv.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(rv.depart,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(rv.arrive,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rv.nb_pass,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(rv.de_jour,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(rv.de_mois,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(rv.de_an,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(rv.a_jour,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(rv.a_mois,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(rv.a_an,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(rv.prix,gtk_entry_get_text(GTK_ENTRY(input11)));

ajouter_reservationvol(rv);

RajouterV=lookup_widget(obj,"RajouterV");

gtk_widget_destroy(RajouterV);
Rvol=create_Rvol();
gtk_widget_show(Rvol);
}

/************************************************Espace Client**********************************************************************/


void
on_RbuttonVol_Eclient_clicked          (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"espaceclient");
 new=create_ResV_Eclient();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"Rsstreeview7");
 Voltree(treeview,"/home/rihab/riri/src/vols.txt");
 gtk_widget_destroy(old);
}


void
on_Rbutton_decnx_Eclient_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *authentification, *espaceclient;

espaceclient=lookup_widget(obj,"espaceclient");

gtk_widget_destroy(espaceclient);
authentification=create_authentification();
gtk_widget_show(authentification);
}

//afficher mes reservation
void
on_Rbuttonmesres_Eclient_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{

}


void
on_RbuttonH_Eclient_clicked            (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"espaceclient");
 new=create_ResH_Eclient();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"RSOtreeview1");
 Hoteltree(treeview,"/home/rihab/riri/src/hotels.txt");
 gtk_widget_destroy(old);
}
/****************************************reserver hotel pour client*****************************************************************/

void
on_Rbuttonres_Eclient_clicked          (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *RajouterH_Eclient, *ResH_Eclient;

ResH_Eclient=lookup_widget(obj,"ResH_Eclient");

gtk_widget_destroy(ResH_Eclient);
RajouterH_Eclient=create_RajouterH_Eclient();
gtk_widget_show(RajouterH_Eclient);
}


void
on_Rbuttonretour_resh_Eclient_clicked  (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *ResH_Eclient, *espaceclient;

ResH_Eclient=lookup_widget(obj,"ResH_Eclient");

gtk_widget_destroy(ResH_Eclient);
espaceclient=create_espaceclient();
gtk_widget_show(espaceclient);
}
/*****************************************************************************************************************************************/

void
on_AcceuilgestionHotel_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
FILE*f1=NULL;
hotel h;
gtk_widget_hide (acceuil);
gestion_Hotel = create_gestion_Hotel ();
p=lookup_widget(gestion_Hotel,"treeview1");
p1=lookup_widget(gestion_Hotel,"treeview3");
i=0;
Hoteltree(p,"hotels.txt");

i=0;
Hoteltree(p1,"hotels.txt");

gtk_widget_show (gestion_Hotel);

}


void
on_AcceuilgestionV_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
FILE*f1=NULL;
vol v;
gtk_widget_hide (acceuil);
gestio_Vol = create_gestio_Vol ();
p=lookup_widget(gestio_Vol,"treeview2");
p1=lookup_widget(gestio_Vol,"treeview4");


j=0;

Voltree(p,"vols.txt");

j=0;

Voltree(p1,"vols.txt");

gtk_widget_show (gestio_Vol);

}


void
on_AcceuiCatalogue_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
FILE*f1=NULL;

gtk_widget_hide (acceuil);
catalogue = create_catalogue ();
p=lookup_widget(catalogue,"treeview5");
p1=lookup_widget(catalogue,"treeview6");


i=0;

Hoteltree(p,"hotels.txt");

j=0;

Voltree(p1,"vols.txt");

gtk_widget_show (catalogue);
}


void
on_AjouterHotel_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *cal1;
GtkWidget *cal2;
GtkWidget *combobox;
GtkWidget *labelNom;
GtkWidget *labelsuccess;
GtkWidget *labelCombo;
GtkWidget *labelExist;
FILE*f=NULL;
hotel h;
int jj1,mm1,aa1,jj2,mm2,aa2,b=1;

labelNom=lookup_widget(gestion_Hotel,"label9");
labelCombo=lookup_widget(gestion_Hotel,"label15");
labelExist=lookup_widget(gestion_Hotel,"label8");
labelsuccess=lookup_widget(gestion_Hotel,"label10");
combobox=lookup_widget(gestion_Hotel,"combobox1");
cal1=lookup_widget(gestion_Hotel,"calendar1");
cal2=lookup_widget(gestion_Hotel,"calendar2");
           gtk_widget_hide (labelsuccess);

strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Hotel,"entry1"))));
// saisie controlé
if(strcmp(h.nom,"")==0){
                gtk_widget_show (labelNom);
b=0;

}else
{
           gtk_widget_hide (labelNom);
}

if(gtk_combo_box_get_active (GTK_COMBO_BOX(combobox))==-1){
                gtk_widget_show (labelCombo);
b=0;
}
else{

           gtk_widget_hide (labelCombo);
}
if(b==1){

h.nbChambre =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Hotel,"spinbutton1")));
h.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Hotel,"spinbutton2")));
strcpy(h.typeChambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
//recuperer la date du calendrier jour,mois,annee
gtk_calendar_get_date (GTK_CALENDAR(cal1),
                       &aa1,
                       &mm1,
                       &jj1);
gtk_calendar_get_date (GTK_CALENDAR(cal2),
                       &aa2,
                       &mm2,
                       &jj2);
if(exist(h.nom)==1) {

                gtk_widget_show (labelExist);

}
else{
           gtk_widget_hide (labelExist);
f=fopen("hotels.txt","a+");
fprintf(f,"%s %s %d/%d/%d %d/%d/%d %d %d\n",h.nom,h.typeChambre,jj1,mm1+1,aa1,jj2,mm2+1,aa2,h.nbChambre,h.prix);
fclose(f);
                gtk_widget_show (labelsuccess);


/*mise a jour du treeView*/
GtkWidget *p;
p=lookup_widget(gestion_Hotel,"treeview1");
Hoteltree(p,"hotels.txt");



}
}
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


 	gchar *nom;
        gchar *typeChambre;
        gchar *dateAdmission;
        gchar *dateSortie;
        gint prix;
        gint nbChambre;

        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion_Hotel,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
                gtk_tree_model_get (model,&iter,0,&nom,1,&typeChambre,2,&dateAdmission,3,&dateSortie,4,&nbChambre,5,&prix,-1);//recuperer les information de la ligne selectionneé

                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion_Hotel,"entry2")),dateAdmission);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion_Hotel,"entry3")),dateSortie);

                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestion_Hotel,"spinbutton4")),prix);
                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestion_Hotel,"spinbutton3")),nbChambre);

                if(strcmp(typeChambre,"Simple")==0) x=0;
                if(strcmp(typeChambre,"Double")==0) x=1;




                gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(gestion_Hotel,"combobox2")),x);
		GtkWidget* msg=lookup_widget(gestion_Hotel,"label25");
                gtk_label_set_text(GTK_LABEL(msg),nom);
		


                gtk_widget_show(lookup_widget(gestion_Hotel,"button7"));//afficher le bouton modifier
        GtkWidget* msg1=lookup_widget(gestion_Hotel,"label27");
        gtk_widget_hide(msg1);

}


}


void
on_SupprimerHotel_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

 GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* nom;
        label=lookup_widget(gestion_Hotel,"label27");
        p=lookup_widget(gestion_Hotel,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&nom,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supp(nom);// supprimer la ligne du fichier

           gtk_widget_hide (label);}else{
                gtk_widget_show (label);
        }

}


void
on_ModifierHotel_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

hotel h;
        strcpy(h.nom,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion_Hotel,"label25"))));
        strcpy(h.typeChambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestion_Hotel,"combobox2"))));
        strcpy(h.dateAdmission,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Hotel,"entry2"))));
        strcpy(h.dateSortie,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Hotel,"entry3"))));
        h.nbChambre =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Hotel,"spinbutton3")));
        h.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Hotel,"spinbutton4")));

        supp(h.nom);
        ajout(h);
        Hoteltree(lookup_widget(gestion_Hotel,"treeview1"),"hotels.txt");
        GtkWidget* msg=lookup_widget(gestion_Hotel,"label26");
        gtk_widget_show(msg);


}


void
on_chercherHotel_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelType;
GtkWidget *nbResultat;
GtkWidget *message;
char type[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(gestion_Hotel,"entry7");
labelType=lookup_widget(gestion_Hotel,"label64");
p1=lookup_widget(gestion_Hotel,"treeview3");

strcpy(type,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(type,"")==0){
  gtk_widget_show (labelType);b=0;
}else{
b=1;
gtk_widget_hide (labelType);}

if(b==0){return;}else{

nb=ChercherHotelTree(p1,"hotels.txt",type);//type entry ecrie par lutilisateur
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(gestion_Hotel,"label66");
message=lookup_widget(gestion_Hotel,"label65");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);//set_text n'accepte que chaine de caractere 

gtk_widget_show (nbResultat);
gtk_widget_show (message);




}
}


void
on_gestionHotel_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
        gtk_widget_destroy (gestion_Hotel);

}


void
on_gtk_main_quit_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AjouterVol_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cal1;
GtkWidget *cal2;
GtkWidget *comboboxDepart;
GtkWidget *comboboxDestination;
GtkWidget *comboboxCompanie;

GtkWidget *labelid;
GtkWidget *labelsuccess;
GtkWidget *labelComboDepart;
GtkWidget *labelComboDestination;
GtkWidget *labelComboCompanie;
GtkWidget *labelExist;
FILE*f=NULL;
vol v;
int jj1,mm1,aa1,jj2,mm2,aa2,b=1;

labelid=lookup_widget(gestio_Vol,"label38");
labelComboDepart=lookup_widget(gestio_Vol,"label40");
labelComboDestination=lookup_widget(gestio_Vol,"label41");
labelComboCompanie=lookup_widget(gestio_Vol,"label43");
labelExist=lookup_widget(gestio_Vol,"label37");
labelsuccess=lookup_widget(gestio_Vol,"label36");



comboboxDepart=lookup_widget(gestio_Vol,"combobox3");
comboboxDestination=lookup_widget(gestio_Vol,"combobox4");
comboboxCompanie=lookup_widget(gestio_Vol,"combobox5");



cal1=lookup_widget(gestio_Vol,"calendar3");
cal2=lookup_widget(gestio_Vol,"calendar4");
           gtk_widget_hide (labelsuccess);

strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestio_Vol,"entry4"))));

if(strcmp(v.id,"")==0){
                gtk_widget_show (labelid);
b=0;

}else
{
           gtk_widget_hide (labelid);
}

if(gtk_combo_box_get_active (GTK_COMBO_BOX(comboboxDepart))==-1){
                gtk_widget_show (labelComboDepart);
b=0;
}
else{

           gtk_widget_hide (labelComboDepart);
}

if(gtk_combo_box_get_active (GTK_COMBO_BOX(comboboxDestination))==-1){
                gtk_widget_show (labelComboDestination);
b=0;
}
else{

           gtk_widget_hide (labelComboDestination);
}


if(gtk_combo_box_get_active (GTK_COMBO_BOX(comboboxCompanie))==-1){
                gtk_widget_show (labelComboCompanie);
b=0;
}
else{

           gtk_widget_hide (labelComboCompanie);
}


if(b==1){

v.nbVols =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestio_Vol,"spinbutton5")));
v.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestio_Vol,"spinbutton6")));
strcpy(v.depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxDepart)));
strcpy(v.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxDestination)));
strcpy(v.companie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxCompanie)));
//recuperer la date du calendar
gtk_calendar_get_date (GTK_CALENDAR(cal1),
                       &aa1,
                       &mm1,
                       &jj1);
gtk_calendar_get_date (GTK_CALENDAR(cal2),
                       &aa2,
                       &mm2,
                       &jj2);




if(exist_vol(v.id)==1) {

                gtk_widget_show (labelExist);

}
else{
           gtk_widget_hide (labelExist);

f=fopen("vols.txt","a+");
fprintf(f,"%s %s %s %s %d/%d/%d %d/%d/%d %d %d\n",v.id,v.depart,v.destination,v.companie,jj1,mm1+1,aa1,jj2,mm2+1,aa2,v.nbVols,v.prix);
fclose(f);
                gtk_widget_show (labelsuccess);


//mise a jour du treeView
GtkWidget *p;
p=lookup_widget(gestio_Vol,"treeview2");
Voltree(p,"vols.txt");



}
}

}

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

gchar *id;
        gchar *depart;
        gchar *destination;
        gchar *companie;
        gchar *date_depart;
        gchar *date_retour;
        gint prix;
        gint nbVols;

        gint x1=0,x2=0,x3;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestio_Vol,"treeview2");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
                gtk_tree_model_get (model,&iter,0,&id,1,&depart,2,&destination,3,&companie,4,&date_depart,5,&date_retour,6,&nbVols,7,&prix,-1);//recuperer les information de la ligne selectionneé

                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestio_Vol,"entry5")),date_depart);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestio_Vol,"entry6")),date_retour);

                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestio_Vol,"spinbutton7")),nbVols);
                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestio_Vol,"spinbutton8")),prix);


                if(strcmp(depart,"Tunisie")==0)	x1=0;		
                if(strcmp(depart,"Algerie")==0) x1=1;                
                if(strcmp(depart,"Marroc")==0)  x1=2 ;             

                if(strcmp(destination,"Tunisie")==0) x2=0;                 
                if(strcmp(destination,"Algerie")==0) x2=1;                
                if(strcmp(destination,"Marroc")==0)  x2=2; 

                if(strcmp(destination,"Allemagne")==0) x2=3;                 
                if(strcmp(destination,"Etat-Unis")==0) x2=4;                
                if(strcmp(destination,"Italie")==0)  x2=5;                

                if(strcmp(companie,"Tunisair")==0)  x3=0;              
                if(strcmp(companie,"Nouvelair")==0)       x3=1;        		  






                                 gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox7")),x1);
                                 gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox6")),x2);
                                 gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox8")),x3);





		GtkWidget* msg=lookup_widget(gestio_Vol,"label57");
                gtk_label_set_text(GTK_LABEL(msg),id);
		


                gtk_widget_show(lookup_widget(gestio_Vol,"button12"));//afficher le bouton modifier
        GtkWidget* msg1=lookup_widget(gestio_Vol,"label60"); 
        gtk_widget_hide(msg1);//cacher "vol modifié avec succes"


}




}


void
on_SupprimerVol_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* id;
        label=lookup_widget(gestio_Vol,"label59");
        p=lookup_widget(gestio_Vol,"treeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_vol(id);// supprimer la ligne du fichier

           gtk_widget_hide (label);}else{
                gtk_widget_show (label);
        }





}


void
on_ModifierVol_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

	vol v;
        strcpy(v.id,gtk_label_get_text(GTK_LABEL(lookup_widget(gestio_Vol,"label57"))));
        strcpy(v.depart,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox7"))));
        strcpy(v.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox6"))));
        strcpy(v.companie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestio_Vol,"combobox8"))));
        strcpy(v.date_depart,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestio_Vol,"entry5"))));
        strcpy(v.date_retour,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestio_Vol,"entry6"))));
        v.nbVols =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestio_Vol,"spinbutton7")));
        v.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestio_Vol,"spinbutton8")));

        supprimer_vol(v.id);
        ajouter_vol(v);
        Voltree(lookup_widget(gestio_Vol,"treeview2"),"vols.txt");
        GtkWidget* msg=lookup_widget(gestio_Vol,"label60");
        gtk_widget_show(msg);



}


void
on_gestionVol_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
        gtk_widget_destroy (gestio_Vol);

}


void
on_catalogue_Acceuil_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
 gtk_widget_destroy (catalogue);

}


void
on_bouttonrechdhia_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelCompanie;
GtkWidget *nbResultat;
GtkWidget *message;
char companie[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(gestio_Vol,"entry8");
labelCompanie=lookup_widget(gestio_Vol,"label70");
p1=lookup_widget(gestio_Vol,"treeview4");

strcpy(companie,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(companie,"")==0){
  gtk_widget_show (labelCompanie);b=0;
}else{
b=1;
gtk_widget_hide (labelCompanie);}

if(b==0){return;}else{

nb=ChercherVolTree(p1,"vols.txt",companie);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(gestio_Vol,"label71");
message=lookup_widget(gestio_Vol,"label72");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);




}

}

/*********************************bouton prestation admin*********************************************************************************/
void
on_Rbutton5_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *acceuil, *espaceadmin;

espaceadmin=lookup_widget(obj,"espaceadmin");

gtk_widget_destroy(espaceadmin);
acceuil=create_acceuil();
gtk_widget_show(acceuil);
}


/********************************bouton pour acceder prestation admin***********************************************************************/

//valider res
void
on_Rsbutton25_clicked                  (GtkWidget       *obj,
                                        gpointer         user_data)
{

}


void
on_Rbuttonretour_ajout_Eclient_clicked (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"RajouterH_Eclient");
 new=create_ResH_Eclient();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"RSOtreeview1");
 Hoteltree(treeview,"/home/rihab/riri/src/hotels.txt");
 gtk_widget_destroy(old);
}

/****************************************reserver vol pour client****************************************************************************/

void
on_Rssbutton_res_listeV_clicked        (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *ResV_Eclient, *espaceclient;

ResV_Eclient=lookup_widget(obj,"ResV_Eclient");

gtk_widget_destroy(ResV_Eclient);
espaceclient=create_espaceclient();
gtk_widget_show(espaceclient);
}


void
on_Rssbuttonretour_listeV_clicked      (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *ResV_Eclient, *espaceclient;

ResV_Eclient=lookup_widget(obj,"ResV_Eclient");

gtk_widget_destroy(ResV_Eclient);
espaceclient=create_espaceclient();
gtk_widget_show(espaceclient);
}


void
on_Rssbuttonretour_listV_clicked       (GtkWidget       *obj,
                                        gpointer         user_data)
{

}


void
on_Rbutton_valresV_clicked             (GtkWidget       *obj,
                                        gpointer         user_data)
{

}
/******************************************************************************************************************************************/

void
on_YbuttonaffresVoit_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *old;
 GtkWidget *new;
 GtkWidget *treeview;

 old=lookup_widget(obj,"RajouterH_Eclient");
 new=create_ResH_Eclient();

 gtk_widget_show(new);
 treeview=lookup_widget(new,"RSOtreeview1");
 Hoteltree(treeview,"/home/rihab/riri/src/hotels.txt");
 gtk_widget_destroy(old);
}


void
on_YbuttonajoutresVoit_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ybuttonmodif_resVoit_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void Hoteltree(GtkWidget* treeview1,char*l);
void Voltree(GtkWidget* treeview1,char*l);
int ChercherHotelTree(GtkWidget* treeview1,char*l,char*type);
int ChercherVolTree(GtkWidget* treeview1,char*l,char*companie);

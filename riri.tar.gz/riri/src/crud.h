
void ajout( hotel h);
int exist(char*nom);
void supp(char*nom);



/************************/

void ajouter_vol( vol v);
int exist_vol(char*id);
void supprimer_vol(char*id);
